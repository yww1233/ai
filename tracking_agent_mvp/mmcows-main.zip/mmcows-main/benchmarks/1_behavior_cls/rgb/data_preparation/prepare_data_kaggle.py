# Kaggle: organize cropped_bboxes into fold/train/val/test for EfficientNet training
# Run: !python prepare_data_kaggle.py

import os
import shutil
import json
from datetime import datetime
import pytz

CT_time_zone = pytz.timezone('America/Chicago')

# Kaggle paths
CROPPED_BBOXES_DIR = '/kaggle/input/datasets/bigkangaroo/mmcow-cropped-bboxes/cropped_bboxes/behaviors'
CONFIG_FILE = '/kaggle/working/mmcows-main/configs/config_s2.json'
OUTPUT_DIR = '/kaggle/working/data_behavior_classification'


def config_to_datetime(datetime_str):
    naive_datetime = datetime.strptime(datetime_str, '%Y-%m-%d %H:%M:%S')
    return CT_time_zone.localize(naive_datetime)


def parse_time_ranges(time_ranges):
    parsed = {}
    for key, tr in time_ranges.items():
        start = config_to_datetime(tr[0])
        end = config_to_datetime(tr[1])
        parsed[key] = (start, end)
    return parsed


def in_time_ranges(file_datetime, keys, g1_ranges, g2_ranges):
    for key in keys:
        s1, e1 = g1_ranges[key]
        s2, e2 = g2_ranges[key]
        if (s1 <= file_datetime < e1) or (s2 <= file_datetime < e2):
            return True
    return False


def get_datetime_from_filename(filename):
    ts = int(filename[0:10])
    return datetime.fromtimestamp(ts, CT_time_zone)


if __name__ == '__main__':
    with open(CONFIG_FILE) as f:
        config = json.load(f)

    g1 = parse_time_ranges(config['group_1'])
    g2 = parse_time_ranges(config['group_2'])

    behav_dirs = [d for d in os.listdir(CROPPED_BBOXES_DIR)
                  if os.path.isdir(os.path.join(CROPPED_BBOXES_DIR, d))]
    print(f'Behavior classes found: {sorted(behav_dirs)}')

    for fold_name, fold_data in config['folds'].items():
        print(f'\n{fold_name}:')
        for split in ['train', 'val', 'test']:
            for behav in behav_dirs:
                os.makedirs(os.path.join(OUTPUT_DIR, fold_name, split, behav), exist_ok=True)

        counts = {'train': 0, 'val': 0, 'test': 0}
        for behav in behav_dirs:
            behav_path = os.path.join(CROPPED_BBOXES_DIR, behav)
            for filename in sorted(os.listdir(behav_path)):
                if not filename.endswith(('.jpg', '.jpeg', '.png')):
                    continue
                file_dt = get_datetime_from_filename(filename)

                if in_time_ranges(file_dt, fold_data['train'], g1, g2):
                    split = 'train'
                elif in_time_ranges(file_dt, fold_data['val'], g1, g2):
                    split = 'val'
                elif in_time_ranges(file_dt, fold_data['test'], g1, g2):
                    split = 'test'
                else:
                    continue

                src = os.path.join(behav_path, filename)
                dst = os.path.join(OUTPUT_DIR, fold_name, split, behav, filename)
                shutil.copyfile(src, dst)
                counts[split] += 1

        print(f"  train: {counts['train']}, val: {counts['val']}, test: {counts['test']}")

    print('\nDone!')
