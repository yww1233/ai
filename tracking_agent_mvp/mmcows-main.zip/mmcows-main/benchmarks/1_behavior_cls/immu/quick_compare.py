# Quick comparison: MLP (baseline) vs 1D-CNN on fold_1 only
# Run: conda run -n mmcows python quick_compare.py

import numpy as np
from sklearn.preprocessing import StandardScaler
from tensorflow.keras.utils import to_categorical
import yaml, os, json, random, argparse
import warnings
warnings.filterwarnings("ignore")

import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import (Dense, Dropout, BatchNormalization,
                                     Flatten, Conv1D, GlobalAveragePooling1D, Input)
import keras
from tensorflow.keras.metrics import F1Score
from tensorflow.keras.callbacks import EarlyStopping

from dwt import process_dwt
from data_loader import data_loader_s1
from cmb_eval import cmb_eval


def segment_data(data_df, window_size, overlap):
    data = data_df.drop(columns=['behavior'])
    timestamps = data['timestamp'].values
    features = data.iloc[:, 1:].values
    behavior_arr = data_df['behavior'].values
    ts_to_idx = {}
    for idx, ts in enumerate(timestamps):
        ts_to_idx[int(ts)] = idx
    mid_size = window_size // 2
    step = int(window_size * (1 - overlap))
    segments, labels_list = [], []
    for i in range(0, len(data) - window_size, step):
        mid_ts = int(timestamps[i + mid_size])
        if mid_ts in ts_to_idx:
            cid = int(behavior_arr[ts_to_idx[mid_ts]])
            if cid != 0:
                segments.append(features[i:i + window_size])
                labels_list.append(cid)
    return np.array(segments), np.array(labels_list)


def standardize_features(data):
    ns, nt, nf = data.shape
    d = data.reshape(-1, nf)
    for i in range(nf):
        s = StandardScaler()
        d[:, i] = s.fit_transform(d[:, i].reshape(-1, 1)).flatten()
    return d.reshape(ns, nt, nf)


def data_formater(data, n_classes):
    X, y = segment_data(data, 100, 0.5)
    y = y - 1
    y_cat = to_categorical(y, num_classes=n_classes)
    X = process_dwt(X, 100)
    X = standardize_features(X)
    return X, y_cat


def build_mlp(input_shape, num_classes):
    model = Sequential([
        Flatten(input_shape=input_shape),
        Dense(300, activation='relu'), BatchNormalization(), Dropout(0.5),
        Dense(256, activation='relu'), BatchNormalization(), Dropout(0.5),
        Dense(128, activation='relu'), BatchNormalization(), Dropout(0.3),
        Dense(num_classes, activation='softmax')
    ])
    return model


def build_cnn(input_shape, num_classes):
    model = Sequential([
        Input(shape=input_shape),
        Conv1D(64, 5, padding='same'), BatchNormalization(), keras.layers.ReLU(), Dropout(0.3),
        Conv1D(128, 3, padding='same'), BatchNormalization(), keras.layers.ReLU(), Dropout(0.3),
        Conv1D(256, 3, padding='same'), BatchNormalization(), keras.layers.ReLU(), Dropout(0.3),
        GlobalAveragePooling1D(),
        Dense(128, activation='relu'), BatchNormalization(), Dropout(0.3),
        Dense(num_classes, activation='softmax')
    ])
    return model


def evaluate(model, X_test, y_test_cat):
    y_pred = np.argmax(model.predict(X_test, verbose=0), axis=1)
    y_true = np.argmax(y_test_cat, axis=1)
    y_pred += 1
    y_true += 1
    _, _, _, f1_dict = cmb_eval(y_pred, y_true)
    return f1_dict


# ===============================================
if __name__ == '__main__':
    behav_list = ['unknown', 'walking', 'standing', 'feed up', 'feed down', 'licking', 'drinking', 'lying']
    n_classes = 7

    np.random.seed(42)
    tf.random.set_seed(42)
    random.seed(42)

    parser = argparse.ArgumentParser()
    parser.add_argument('--path_dir', type=str, default='../../configs/path.yaml')
    parser.add_argument('--config_dir', type=str, default='../../configs/config_s1.json')
    args = parser.parse_args()

    with open(args.path_dir) as f:
        sensor_data_dir = yaml.safe_load(f)['sensor_data_dir']
    with open(args.config_dir) as f:
        folds = json.load(f)['folds']

    # Only use fold_1 for quick test
    fold_name = 'fold_1'
    fold_config = folds[fold_name]
    print(f'Quick comparison on {fold_name} ...')

    pre_loader = 'immu_pre_data_loader'
    train_df, val_df, test_df = data_loader_s1(pre_loader, sensor_data_dir, fold_config, val=True, timestamp=True)

    print('  processing data ...')
    X_train, y_train = data_formater(train_df, n_classes)
    X_val, y_val = data_formater(val_df, n_classes)
    X_test, y_test = data_formater(test_df, n_classes)

    input_shape = (X_train.shape[1], X_train.shape[2])
    print(f'  data shape: {input_shape}')

    results = {}
    for name, build_fn in [('MLP (baseline)', build_mlp), ('1D-CNN (ours)', build_cnn)]:
        print(f'\n  training {name} ...')
        seed = 42
        np.random.seed(seed)
        tf.random.set_seed(seed)

        model = build_fn(input_shape, n_classes)
        model.compile(
            loss=keras.losses.categorical_crossentropy,
            optimizer='adam',
            metrics=['accuracy']
        )
        model.fit(X_train, y_train, epochs=40, batch_size=16,
                  validation_data=(X_val, y_val),
                  callbacks=[EarlyStopping(monitor='val_loss', patience=5, restore_best_weights=True)],
                  verbose=0)

        f1_dict = evaluate(model, X_test, y_test)
        f1_vals = list(f1_dict.values())
        macro_f1 = np.mean(f1_vals)
        results[name] = (f1_dict, macro_f1)

    # Print comparison
    print('\n' + '='*70)
    print(f'{"":15s} {"MLP (baseline)":>16s} {"1D-CNN (ours)":>16s} {"Improvement":>14s}')
    print('='*70)
    for i, behav in enumerate(behav_list[1:], 1):
        mlp_f1 = results['MLP (baseline)'][0].get(i, 0)
        cnn_f1 = results['1D-CNN (ours)'][0].get(i, 0)
        diff = cnn_f1 - mlp_f1
        print(f'  {behav:12s} {mlp_f1:16.3f} {cnn_f1:16.3f} {diff:+14.3f}')
    print('-'*70)
    mlp_avg = results['MLP (baseline)'][1]
    cnn_avg = results['1D-CNN (ours)'][1]
    print(f'  {"Macro avg":12s} {mlp_avg:16.3f} {cnn_avg:16.3f} {cnn_avg-mlp_avg:+14.3f}')
    print('='*70)
