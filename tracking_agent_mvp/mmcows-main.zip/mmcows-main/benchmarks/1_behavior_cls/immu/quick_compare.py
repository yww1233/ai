# Quick comparison: MLP vs CNN vs CNN+class_weight vs CNN+focal_loss (fold_1)
# Run: conda run -n mmcows python quick_compare.py

import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.utils.class_weight import compute_class_weight
from tensorflow.keras.utils import to_categorical
import yaml, os, json, random, argparse
import warnings
warnings.filterwarnings("ignore")

import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import (Dense, Dropout, BatchNormalization,
                                     Flatten, Conv1D, GlobalAveragePooling1D, Input)
import keras
from tensorflow.keras.callbacks import EarlyStopping

from dwt import process_dwt
from data_loader import data_loader_s1
from cmb_eval import cmb_eval


def segment_data(data_df, window_size, overlap):
    data = data_df.drop(columns=['behavior'])
    timestamps = data['timestamp'].values
    features = data.iloc[:, 1:].values
    behavior_arr = data_df['behavior'].values
    ts_to_idx = {}
    for idx, ts in enumerate(timestamps):
        ts_to_idx[int(ts)] = idx
    mid_size = window_size // 2
    step = int(window_size * (1 - overlap))
    segments, labels_list = [], []
    for i in range(0, len(data) - window_size, step):
        mid_ts = int(timestamps[i + mid_size])
        if mid_ts in ts_to_idx:
            cid = int(behavior_arr[ts_to_idx[mid_ts]])
            if cid != 0:
                segments.append(features[i:i + window_size])
                labels_list.append(cid)
    return np.array(segments), np.array(labels_list)


def standardize_features(data):
    ns, nt, nf = data.shape
    d = data.reshape(-1, nf)
    for i in range(nf):
        s = StandardScaler()
        d[:, i] = s.fit_transform(d[:, i].reshape(-1, 1)).flatten()
    return d.reshape(ns, nt, nf)


def data_formater(data, n_classes):
    X, y = segment_data(data, 100, 0.5)
    y = y - 1
    y_cat = to_categorical(y, num_classes=n_classes)
    X = process_dwt(X, 100)
    X = standardize_features(X)
    return X, y_cat, y


def focal_loss(gamma=2.0, alpha=0.25):
    """Focal Loss for handling class imbalance."""
    def loss_fn(y_true, y_pred):
        y_pred = tf.clip_by_value(y_pred, 1e-7, 1.0 - 1e-7)
        cross_entropy = -y_true * tf.math.log(y_pred)
        weight = alpha * y_true * tf.pow(1.0 - y_pred, gamma)
        return tf.reduce_sum(weight * cross_entropy, axis=-1)
    return loss_fn


def get_class_weights(y_int, n_classes):
    """Compute balanced class weights from integer labels."""
    classes = np.arange(n_classes)
    weights = compute_class_weight('balanced', classes=classes, y=y_int)
    return dict(zip(classes, weights))


def build_mlp(input_shape, num_classes):
    model = Sequential([
        Flatten(input_shape=input_shape),
        Dense(300, activation='relu'), BatchNormalization(), Dropout(0.5),
        Dense(256, activation='relu'), BatchNormalization(), Dropout(0.5),
        Dense(128, activation='relu'), BatchNormalization(), Dropout(0.3),
        Dense(num_classes, activation='softmax')
    ])
    return model


def build_cnn(input_shape, num_classes):
    model = Sequential([
        Input(shape=input_shape),
        Conv1D(64, 5, padding='same'), BatchNormalization(), keras.layers.ReLU(), Dropout(0.3),
        Conv1D(128, 3, padding='same'), BatchNormalization(), keras.layers.ReLU(), Dropout(0.3),
        Conv1D(256, 3, padding='same'), BatchNormalization(), keras.layers.ReLU(), Dropout(0.3),
        GlobalAveragePooling1D(),
        Dense(128, activation='relu'), BatchNormalization(), Dropout(0.3),
        Dense(num_classes, activation='softmax')
    ])
    return model


def evaluate(model, X_test, y_test_cat):
    y_pred = np.argmax(model.predict(X_test, verbose=0), axis=1)
    y_true = np.argmax(y_test_cat, axis=1)
    y_pred += 1
    y_true += 1
    _, _, _, f1_dict = cmb_eval(y_pred, y_true)
    return f1_dict


# ===============================================
if __name__ == '__main__':
    behav_list = ['unknown', 'walking', 'standing', 'feed up', 'feed down', 'licking', 'drinking', 'lying']
    n_classes = 7

    np.random.seed(42)
    tf.random.set_seed(42)
    random.seed(42)

    parser = argparse.ArgumentParser()
    parser.add_argument('--path_dir', type=str, default='../../configs/path.yaml')
    parser.add_argument('--config_dir', type=str, default='../../configs/config_s1.json')
    args = parser.parse_args()

    with open(args.path_dir) as f:
        sensor_data_dir = yaml.safe_load(f)['sensor_data_dir']
    with open(args.config_dir) as f:
        folds = json.load(f)['folds']

    fold_name = 'fold_1'
    fold_config = folds[fold_name]
    print(f'Quick comparison on {fold_name} ...')

    pre_loader = 'immu_pre_data_loader'
    train_df, val_df, test_df = data_loader_s1(pre_loader, sensor_data_dir, fold_config, val=True, timestamp=True)

    print('  processing data ...')
    X_train, y_train, y_train_int = data_formater(train_df, n_classes)
    X_val, y_val, _ = data_formater(val_df, n_classes)
    X_test, y_test, _ = data_formater(test_df, n_classes)

    input_shape = (X_train.shape[1], X_train.shape[2])
    print(f'  data shape: {input_shape}')

    # --- Class distribution ---
    class_weights = get_class_weights(y_train_int, n_classes)
    print('\n  Class distribution (train):')
    for i, behav in enumerate(behav_list[1:], 0):
        count = np.sum(y_train_int == i)
        print(f'    {behav:12s}: {count:6d}  weight={class_weights[i]:.2f}')

    # --- Training configs: focal loss alpha sweep ---
    experiments = [
        ('MLP baseline',           build_mlp, 'ce',      None,  None, None),
        ('CNN+ce+w',               build_cnn, 'ce',      class_weights, None, None),
        ('CNN+focal a=0.25',       build_cnn, 'focal',   class_weights, 2.0, 0.25),
        ('CNN+focal a=0.50',       build_cnn, 'focal',   class_weights, 2.0, 0.50),
        ('CNN+focal a=0.75',       build_cnn, 'focal',   class_weights, 2.0, 0.75),
        ('CNN+focal g=1 a=0.5',    build_cnn, 'focal',   class_weights, 1.0, 0.50),
    ]

    results = {}
    for name, build_fn, loss_type, cw, gamma, alpha in experiments:
        print(f'\n  training {name} ...')
        seed = 42
        np.random.seed(seed)
        tf.random.set_seed(seed)

        model = build_fn(input_shape, n_classes)
        if loss_type == 'focal':
            loss_fn = focal_loss(gamma=gamma, alpha=alpha)
        else:
            loss_fn = keras.losses.categorical_crossentropy

        model.compile(loss=loss_fn, optimizer='adam', metrics=['accuracy'])
        model.fit(X_train, y_train, epochs=40, batch_size=16,
                  validation_data=(X_val, y_val),
                  class_weight=cw,
                  callbacks=[EarlyStopping(monitor='val_loss', patience=5, restore_best_weights=True)],
                  verbose=0)

        f1_dict = evaluate(model, X_test, y_test)
        f1_vals = list(f1_dict.values())
        macro_f1 = np.mean(f1_vals)
        results[name] = (f1_dict, macro_f1)

    # --- Print comparison ---
    names = [e[0] for e in experiments]
    col_w = max(len(n) for n in names) + 3
    col_w = max(col_w, 18)
    hdr = f'{"":12s}' + ''.join(f'{n:>{col_w}s}' for n in names)
    sep = '=' * (14 + col_w * len(names))
    print('\n' + sep)
    print(hdr)
    print(sep)
    for i, behav in enumerate(behav_list[1:], 1):
        row = f'  {behav:10s}'
        for n in names:
            row += f'{results[n][0].get(i, 0):{col_w}.3f}'
        print(row)
    print('-' * (14 + col_w * len(names)))
    row = f'  {"Macro avg":10s}'
    for n in names:
        row += f'{results[n][1]:{col_w}.3f}'
    print(row)
    print(sep)
