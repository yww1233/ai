
import numpy as np
from cmb_eval import cmb_eval

from tensorflow.keras.models import Sequential, Model
from tensorflow.keras.layers import (Dense, Dropout, BatchNormalization,
                                     Conv1D, GlobalAveragePooling1D, Input)
from tensorflow.keras.callbacks import EarlyStopping, ModelCheckpoint
import keras
from tensorflow.keras.metrics import F1Score
import tensorflow as tf
import random
import os
import warnings

warnings.filterwarnings("ignore")


def cnn_classifer(moda, fold_name, train_data, val_data, test_data, num_classes, train=False, verbose=1):

    seed = 42
    np.random.seed(seed)
    tf.random.set_seed(seed)
    random.seed(seed)
    tf.config.experimental.enable_op_determinism()

    X_train, y_train = train_data
    X_val, y_val = val_data
    X_test, y_test = test_data

    window_size = X_train.shape[1]
    n_features = X_train.shape[2]

    batch_size = 16
    epochs = 40

    input_shape = (window_size, n_features)

    # --- 1D-CNN model: preserves temporal structure ---
    model = Sequential()

    model.add(Input(shape=input_shape))

    # Block 1
    model.add(Conv1D(64, kernel_size=5, padding='same'))
    model.add(BatchNormalization())
    model.add(keras.layers.ReLU())
    model.add(Dropout(0.3))

    # Block 2
    model.add(Conv1D(128, kernel_size=3, padding='same'))
    model.add(BatchNormalization())
    model.add(keras.layers.ReLU())
    model.add(Dropout(0.3))

    # Block 3
    model.add(Conv1D(256, kernel_size=3, padding='same'))
    model.add(BatchNormalization())
    model.add(keras.layers.ReLU())
    model.add(Dropout(0.3))

    # Pool temporal dimension → fixed-size feature vector
    model.add(GlobalAveragePooling1D())

    # Classifier head
    model.add(Dense(128, activation='relu'))
    model.add(BatchNormalization())
    model.add(Dropout(0.3))
    model.add(Dense(num_classes, activation='softmax'))

    model.compile(
        loss=keras.losses.categorical_crossentropy,
        optimizer=keras.optimizers.legacy.Adam(),
        metrics=['accuracy', F1Score()]
    )

    # Weight save path (avoid Chinese chars in path for TF on Windows)
    weight_base = os.path.join(os.environ.get('TEMP', 'C:/temp'), 'mmcows_weights')
    weight_dir = os.path.join(weight_base, moda, fold_name + '.h5')

    if train:
        early_stop = EarlyStopping(monitor='val_loss', patience=5, restore_best_weights=True)
        checkpoint = ModelCheckpoint(filepath=weight_dir,
                                     monitor='val_loss',
                                     save_best_only=True,
                                     mode='min')

        history = model.fit(X_train, y_train,
                            epochs=epochs,
                            batch_size=batch_size,
                            validation_data=(X_val, y_val),
                            callbacks=[early_stop, checkpoint],
                            verbose=verbose)
    else:
        model.load_weights(weight_dir)

    y_pred = model.predict(X_test)
    y_pred = np.argmax(y_pred, axis=1)
    y_test = np.argmax(y_test, axis=1)

    y_pred += 1
    y_test += 1

    acc_dict, prec_dict, recal_dict, f1_dict = cmb_eval(y_pred, y_test)

    return acc_dict, prec_dict, recal_dict, f1_dict
