# Visualization: Confusion Matrix + t-SNE for S1 CNN+Focal model
# Run: python visualize.py

import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
from sklearn.utils.class_weight import compute_class_weight
from sklearn.manifold import TSNE
from tensorflow.keras.utils import to_categorical
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import (Dense, Dropout, BatchNormalization,
                                     Conv1D, GlobalAveragePooling1D, Input)
import keras
import tensorflow as tf
from sklearn.metrics import confusion_matrix, ConfusionMatrixDisplay
import yaml, os, json, random, argparse
import warnings
warnings.filterwarnings("ignore")

from dwt import process_dwt
from data_loader import data_loader_s1


def segment_data(data_df, window_size, overlap):
    data = data_df.drop(columns=['behavior'])
    timestamps = data['timestamp'].values
    features = data.iloc[:, 1:].values
    behavior_arr = data_df['behavior'].values
    ts_to_idx = {}
    for idx, ts in enumerate(timestamps):
        ts_to_idx[int(ts)] = idx
    mid_size = window_size // 2
    step = int(window_size * (1 - overlap))
    segments, labels_list = [], []
    for i in range(0, len(data) - window_size, step):
        mid_ts = int(timestamps[i + mid_size])
        if mid_ts in ts_to_idx:
            cid = int(behavior_arr[ts_to_idx[mid_ts]])
            if cid != 0:
                segments.append(features[i:i + window_size])
                labels_list.append(cid)
    return np.array(segments), np.array(labels_list)


def standardize_features(data):
    ns, nt, nf = data.shape
    d = data.reshape(-1, nf)
    for i in range(nf):
        s = StandardScaler()
        d[:, i] = s.fit_transform(d[:, i].reshape(-1, 1)).flatten()
    return d.reshape(ns, nt, nf)


def data_formater(data, n_classes):
    X, y = segment_data(data, 100, 0.5)
    y = y - 1
    y_cat = to_categorical(y, num_classes=n_classes)
    X = process_dwt(X, 100)
    X = standardize_features(X)
    return X, y_cat, y


def focal_loss(gamma=1.0, alpha=0.5):
    def loss_fn(y_true, y_pred):
        y_pred = tf.clip_by_value(y_pred, 1e-7, 1.0 - 1e-7)
        cross_entropy = -y_true * tf.math.log(y_pred)
        weight = alpha * y_true * tf.pow(1.0 - y_pred, gamma)
        return tf.reduce_sum(weight * cross_entropy, axis=-1)
    return loss_fn


def build_cnn(input_shape, num_classes):
    model = Sequential([
        Input(shape=input_shape),
        Conv1D(64, 5, padding='same'), BatchNormalization(), keras.layers.ReLU(), Dropout(0.3),
        Conv1D(128, 3, padding='same'), BatchNormalization(), keras.layers.ReLU(), Dropout(0.3),
        Conv1D(256, 3, padding='same'), BatchNormalization(), keras.layers.ReLU(), Dropout(0.3),
        GlobalAveragePooling1D(),
        Dense(128, activation='relu'), BatchNormalization(), Dropout(0.3),
        Dense(num_classes, activation='softmax')
    ])
    return model


def extract_features(model, X):
    """Extract features from GlobalAveragePooling1D layer (before classifier head)."""
    feature_model = Sequential(model.layers[:-3])
    return feature_model.predict(X, verbose=0)


# ===============================================
if __name__ == '__main__':
    behav_list = ['walking', 'standing', 'feed up', 'feed down', 'licking', 'drinking', 'lying']
    n_classes = 7

    np.random.seed(42)
    tf.random.set_seed(42)
    random.seed(42)

    parser = argparse.ArgumentParser()
    parser.add_argument('--path_dir', type=str, default='../../configs/path.yaml')
    parser.add_argument('--config_dir', type=str, default='../../configs/config_s1.json')
    args = parser.parse_args()

    with open(args.path_dir) as f:
        sensor_data_dir = yaml.safe_load(f)['sensor_data_dir']
    with open(args.config_dir) as f:
        folds = json.load(f)['folds']

    # Use fold_1 for visualization
    fold_name = 'fold_1'
    fold_config = folds[fold_name]
    print(f'Visualizing on {fold_name} ...')

    pre_loader = 'immu_pre_data_loader'
    train_df, val_df, test_df = data_loader_s1(pre_loader, sensor_data_dir, fold_config, val=True, timestamp=True)

    print('  processing data ...')
    X_train, y_train, y_train_int = data_formater(train_df, n_classes)
    X_val, y_val, _ = data_formater(val_df, n_classes)
    X_test, y_test, y_test_int = data_formater(test_df, n_classes)

    input_shape = (X_train.shape[1], X_train.shape[2])

    # Train model (or load if exists)
    print('  training CNN + focal_loss ...')
    model = build_cnn(input_shape, n_classes)
    model.compile(loss=focal_loss(1.0, 0.5), optimizer='adam', metrics=['accuracy'])

    classes = np.arange(n_classes)
    weights = compute_class_weight('balanced', classes=classes, y=y_train_int)
    class_weights = dict(zip(classes, weights))

    from tensorflow.keras.callbacks import EarlyStopping
    model.fit(X_train, y_train, epochs=40, batch_size=16,
              validation_data=(X_val, y_val),
              class_weight=class_weights,
              callbacks=[EarlyStopping(monitor='val_loss', patience=5, restore_best_weights=True)],
              verbose=1)

    # Predictions
    y_pred = np.argmax(model.predict(X_test, verbose=0), axis=1)
    y_true = np.argmax(y_test, axis=1)

    # --- 1. Confusion Matrix ---
    cm = confusion_matrix(y_true, y_pred)
    fig, ax = plt.subplots(figsize=(8, 6))
    disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=behav_list)
    disp.plot(ax=ax, cmap='Blues', values_format='d', xticks_rotation=45)
    ax.set_title('Confusion Matrix - CNN + Focal Loss (S1 fold_1)', fontsize=12)
    plt.tight_layout()
    plt.savefig('confusion_matrix.png', dpi=150, bbox_inches='tight')
    print('  saved confusion_matrix.png')

    # --- 2. Normalized Confusion Matrix ---
    cm_norm = cm.astype('float') / cm.sum(axis=1)[:, np.newaxis]
    fig, ax = plt.subplots(figsize=(8, 6))
    disp = ConfusionMatrixDisplay(confusion_matrix=cm_norm, display_labels=behav_list)
    disp.plot(ax=ax, cmap='Blues', values_format='.2f', xticks_rotation=45)
    ax.set_title('Normalized Confusion Matrix - CNN + Focal Loss (S1 fold_1)', fontsize=12)
    plt.tight_layout()
    plt.savefig('confusion_matrix_norm.png', dpi=150, bbox_inches='tight')
    print('  saved confusion_matrix_norm.png')

    # --- 3. t-SNE visualization ---
    print('  extracting features for t-SNE ...')
    features = extract_features(model, np.concatenate([X_train, X_test]))
    labels = np.concatenate([y_train_int, y_test_int])
    is_test = np.concatenate([np.zeros(len(X_train)), np.ones(len(X_test))])

    # Subsample for t-SNE speed (max 3000 points)
    n_total = len(features)
    if n_total > 3000:
        idx = np.random.choice(n_total, 3000, replace=False)
        features_sub = features[idx]
        labels_sub = labels[idx]
        is_test_sub = is_test[idx]
    else:
        features_sub = features
        labels_sub = labels
        is_test_sub = is_test

    print(f'  running t-SNE on {len(features_sub)} points ...')
    tsne = TSNE(n_components=2, random_state=42, perplexity=30)
    embeddings = tsne.fit_transform(features_sub)

    # Plot colored by class
    fig, axes = plt.subplots(1, 2, figsize=(16, 6))

    colors = plt.cm.Set2(np.linspace(0, 1, n_classes))
    for c in range(n_classes):
        mask = labels_sub == c
        axes[0].scatter(embeddings[mask, 0], embeddings[mask, 1],
                        c=[colors[c]], label=behav_list[c], s=10, alpha=0.6)
    axes[0].set_title('t-SNE (colored by behavior class)', fontsize=12)
    axes[0].legend(fontsize=8, markerscale=2)
    axes[0].set_xticks([])
    axes[0].set_yticks([])

    # Plot colored by train/test
    for split, label, color in [(0, 'Train', '#2196F3'), (1, 'Test', '#F44336')]:
        mask = is_test_sub == split
        axes[1].scatter(embeddings[mask, 0], embeddings[mask, 1],
                        c=color, label=label, s=10, alpha=0.6)
    axes[1].set_title('t-SNE (colored by train/test split)', fontsize=12)
    axes[1].legend(fontsize=10, markerscale=2)
    axes[1].set_xticks([])
    axes[1].set_yticks([])

    plt.tight_layout()
    plt.savefig('tsne_visualization.png', dpi=150, bbox_inches='tight')
    print('  saved tsne_visualization.png')

    print('\nDone! Generated 3 figures.')
