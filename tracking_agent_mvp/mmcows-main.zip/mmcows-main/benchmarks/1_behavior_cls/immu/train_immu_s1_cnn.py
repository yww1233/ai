# IMMU - 1D-CNN improved version

import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.utils.class_weight import compute_class_weight
from tensorflow.keras.utils import to_categorical
import yaml, os
import json
import random
import argparse
from dwt import process_dwt

from data_loader import data_loader_s1
from cnn_classifer import cnn_classifer


# Function to segment data into 10-second windows with 50% overlap
def segment_data(data_df, window_size, overlap):
    data = data_df.drop(columns=['behavior'])
    timestamps = data['timestamp'].values
    features = data.iloc[:, 1:].values
    behavior_arr = data_df['behavior'].values

    ts_to_idx = {}
    for idx, ts in enumerate(timestamps):
        ts_to_idx[int(ts)] = idx

    mid_size = window_size // 2
    step = int(window_size * (1 - overlap))
    segments = []
    labels_list = []
    for i in range(0, len(data) - window_size, step):
        mid_timestamp = int(timestamps[i + mid_size])
        if mid_timestamp in ts_to_idx:
            class_id = int(behavior_arr[ts_to_idx[mid_timestamp]])
            if class_id != 0:
                segments.append(features[i:i + window_size])
                labels_list.append(class_id)
    return np.array(segments), np.array(labels_list)


def standardize_features(data):
    num_samples, num_timesteps, num_features = data.shape
    data_reshaped = data.reshape(-1, num_features)
    standardized_data = data_reshaped.copy()
    for i in range(num_features):
        scaler = StandardScaler()
        standardized_data[:, i] = scaler.fit_transform(data_reshaped[:, i].reshape(-1, 1)).flatten()
    standardized_data = standardized_data.reshape(num_samples, num_timesteps, num_features)
    return standardized_data


def data_formater(data):
    window_size = 100
    overlap = 0.5

    X, y = segment_data(data, window_size, overlap)
    y = y - 1

    y_cat = to_categorical(y, num_classes=n_classes)

    X = process_dwt(X, window_size)
    X = standardize_features(X)

    return X, y_cat, y


# ===============================================
if __name__ == '__main__':

    print('\nMODALITY: IMMU (S1) - 1D-CNN improved --------------------------------------------')
    behav_list = ['unknown', 'walking', 'standing', 'feed up', 'feed down', 'licking', 'drinking', 'lying']

    train = True
    random.seed(42)

    date = '0725'
    n_features = 4
    n_classes = 7

    config = 's1'
    moda = 'immu_cnn_' + config
    config_name = 'config_' + config + '.json'

    current_dir = os.path.join(os.path.dirname(__file__))

    parser = argparse.ArgumentParser(description='Test')
    parser.add_argument('--path_dir', type=str, default=os.path.join(current_dir, 'private', "path.yaml"))
    parser.add_argument('--config_dir', type=str, default=os.path.join(current_dir, 'private', config_name))
    args = parser.parse_args()

    yaml_dir = args.path_dir
    json_dir = args.config_dir

    with open(yaml_dir, 'r') as file:
        file_dirs = yaml.safe_load(file)
    sensor_data_dir = file_dirs['sensor_data_dir']

    with open(json_dir, 'r') as f:
        config = json.load(f)

    folds = config['folds']

    aggregated_f1 = {}

    for fold_name, fold_config in folds.items():
        print(f"\n{fold_name}:")

        pre_loader = 'immu_pre_data_loader'
        train_data, val_data, test_data = data_loader_s1(pre_loader, sensor_data_dir, fold_config, val=True, timestamp=True)

        print('\tprocessing data ...')
        if train:
            X_train, y_train, y_train_int = data_formater(train_data)
            X_val, y_val, _ = data_formater(val_data)
            X_test, y_test, _ = data_formater(test_data)

            # Compute balanced class weights
            classes = np.arange(n_classes)
            weights = compute_class_weight('balanced', classes=classes, y=y_train_int)
            class_weights = dict(zip(classes, weights))

            train_data = (X_train, y_train)
            val_data = (X_val, y_val)
            test_data = (X_test, y_test)

            print('\ttraining (1D-CNN + focal_loss) ...')
        else:
            X_test, y_test, _ = data_formater(test_data)
            test_data = (X_test, y_test)
            train_data = test_data
            val_data = test_data
            class_weights = None
            print('\ttesting ...')

        acc_dict, prec_dict, recal_dict, f1_dict = cnn_classifer(
            moda, fold_name, train_data, val_data, test_data,
            num_classes=n_classes, train=train, verbose=0,
            class_weight=class_weights, loss_type='focal'
        )

        for key, value in f1_dict.items():
            if key not in aggregated_f1:
                aggregated_f1[key] = []
            aggregated_f1[key].append(value)

    print('\nRESULTS:', moda)

    mean_std_results = {key: (np.mean(values), np.std(values)) for key, values in aggregated_f1.items()}

    for key, (mean, std) in mean_std_results.items():
        print(f"\tClass {key} F1: {mean:.3f}±{std:.3f}  ({behav_list[int(key)]})")

    mean_f1_scores = [mean for mean, std in mean_std_results.values()]
    std_f1_scores = [std for mean, std in mean_std_results.values()]
    macro_average_f1 = np.mean(mean_f1_scores)
    average_error_f1 = np.mean(std_f1_scores)

    print(f"\tMacro avg F1: {macro_average_f1:.3f}±{average_error_f1:.3f}")
